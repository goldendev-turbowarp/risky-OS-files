MINICRAFT LOCAL PACKAGE

1. Extract the entire ZIP to a folder, then double-click start-local-server.bat.
2. Open http://localhost:8080 in your browser.

Files:
- index.html: game
- assets/: local runtime libraries
- mods/: place standalone local mod files
- config.json: package defaults
- biome_atribute.json: colors, biome selection, terrain weirdness and tree spawn chances
- recepies.json: recipes (the correctly spelled recipes.json is also supported)
- mods/feature-demo.zip: sample mod using features/*.json

Use start-local-server.bat to load package JSON files and texture packs. Browsers block
JSON fetch on file:// pages; direct-file mode uses the embedded biome defaults instead.
Each biome's treeSpawnChance values are probabilities per X/Z column; weirdness (0-1)
controls terrain roughness, and grassColor/foliageColor are #RRGGBB tint values.
On touch devices, use the left joystick to move, drag the right side to look, and use
the on-screen buttons to jump, break, or place blocks.
Built-in game textures are generated in index.html. Mod textures belong inside each
mod ZIP and are loaded from that pack's assets.

Minecraft 1.12.2 resource packs can be imported from the Mods menu. The ZIP must
contain pack.mcmeta with pack_format 3 and block PNGs under
assets/minecraft/textures/blocks/. Only mapped block textures are used; pack scripts
and other content are ignored. Grass and oak leaves are tinted by generated biome
climate (plains, forest, desert, taiga, swamp, and snowy); the current biome is shown
in the in-game coordinate display. Plains generate birch trees, while snowy biomes
generate snow-covered ground and conical pine trees.

Feature mod ZIPs need a manifest.json at their root and one JSON per resource under
features/. Each resource has a "type" and a "feat.info" object. Behavior resources
may point to a JavaScript file with feat.info.script. The ZIP importer runs that code,
so only install mods from sources you trust.
3D model entries and assets are imported as metadata; the game does not render custom
3D models yet.
