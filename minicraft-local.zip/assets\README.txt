This folder contains the local runtime libraries used by the game.
Textures for individual mods are stored inside each mod ZIP.
